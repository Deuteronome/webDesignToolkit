import { startAnim } from "./startAnim.js";
import { pageNavigation } from "./pageNavigation.js";
import { tileManager } from "./tileManager.js";

startAnim()
pageNavigation()
tileManager()