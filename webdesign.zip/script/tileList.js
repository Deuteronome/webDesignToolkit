export let tileList = [
    {
        'url' : 'https://www.canva.com/fr_fr/',
        'rec' : '../assets/tileBkgd/canvaRec.png',
        'ver' : '../assets/tileBkgd/canvaVer.png'
    },
    {
        'url' : 'https://www.behance.net/',
        'rec' : '../assets/tileBkgd/behanceRec.png',
        'ver' : '../assets/tileBkgd/behanceVer.png'
    },
    {
        'url' : 'https://muz.li/fr',
        'rec' : '../assets/tileBkgd/muzliRec.png',
        'ver' : '../assets/tileBkgd/muzliVer.png'
    },
    {
        'url' : 'https://www.pinterest.fr/',
        'rec' : '../assets/tileBkgd/pinterestRec.png',
        'ver' : '../assets/tileBkgd/pinterestVer.png'
    },
    {
        'url' : 'https://www.instagram.com/',
        'rec' : '../assets/tileBkgd/instagramRec.png',
        'ver' : '../assets/tileBkgd/instagramVer.png'
    },
    {
        'url' : 'https://www.neographefactory.com/toolbox/inspirations',
        'rec' : '../assets/tileBkgd/ngrpRec.png',
        'ver' : '../assets/tileBkgd/ngrpVer.png'
    }
]